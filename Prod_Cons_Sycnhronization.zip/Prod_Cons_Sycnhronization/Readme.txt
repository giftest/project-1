
1. Install VirtualBox in windows to use in non-Linux environment.
This program is written in C++.

First you compile and run both programs in separate terminal windows. 
The producer will produce items and put them on the table, and the consumer will pick up items from the table, following the synchronization rules of the producer-consumer problem.

compilation and execution 

$ gcc producer.c -pthread -lrt -o producer
$ gcc consumer.c -pthread -lrt -o consumer
$ ./producer & ./consumer &


This project demonstrates the synchronization between the producer and the consumer in the producer-consumer problem.


 





